<?php
// Usage:
// 	http://www.mydomain.com/path_to_folder/this_filename.php/hello/Alpha/Beta
// Will output:
// 	Hello, Alpha, Beta

include_once ("Slim/Slim.php");
\Slim\Slim::registerAutoloader();

$app = new \Slim\Slim();
$app->get('/hello/:name/:name2', function ($nameone,$two) {
    echo "Hello, $nameone, $two";
});
$app->run();
?>
